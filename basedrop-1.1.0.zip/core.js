/* BaseDrop core – pure logic, no DOM. Works in extension pages and Node (tests). */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.BaseDrop = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  const API = 'https://api.airtable.com/v0';
  const FREE_FILE_LIMIT = 50;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  /* ---------- Rate limiter: max N requests per window (default 5/s per base) ---------- */
  class RateLimiter {
    constructor(max = 5, windowMs = 1000, now = () => Date.now(), wait = sleep) {
      this.max = max; this.windowMs = windowMs; this.now = now; this.wait = wait; this.stamps = [];
    }
    async take() {
      for (;;) {
        const t = this.now();
        this.stamps = this.stamps.filter((s) => t - s < this.windowMs);
        if (this.stamps.length < this.max) { this.stamps.push(t); return; }
        await this.wait(this.windowMs - (t - this.stamps[0]) + 5);
      }
    }
  }

  class ApiError extends Error {
    constructor(status, message, type) { super(message); this.status = status; this.type = type; }
  }

  /* ---------- Airtable Web API client ---------- */
  class AirtableClient {
    constructor(token, opts = {}) {
      if (!token) throw new Error('Missing personal access token');
      this.token = token;
      this.fetch = opts.fetch || ((...a) => fetch(...a));
      this.wait = opts.wait || sleep;
      this.limiter = opts.limiter || new RateLimiter(4, 1000, undefined, this.wait); // stay under 5/s
      this.maxRetries = opts.maxRetries ?? 5;
      this.calls = 0;
      this.onWait = opts.onWait || (() => {});
    }
    async request(path, params = {}) {
      const u = new URL(API + path);
      for (const [k, v] of Object.entries(params)) {
        if (v === undefined || v === null || v === '') continue;
        if (Array.isArray(v)) v.forEach((x) => u.searchParams.append(k + '[]', x));
        else u.searchParams.set(k, v);
      }
      for (let attempt = 0; ; attempt++) {
        await this.limiter.take();
        this.calls++;
        let res;
        try {
          res = await this.fetch(u.toString(), { headers: { Authorization: 'Bearer ' + this.token } });
        } catch (e) {
          if (attempt >= this.maxRetries) throw new ApiError(0, 'Network error: ' + e.message, 'NETWORK');
          await this.wait(1000 * 2 ** attempt); continue;
        }
        if (res.status === 429) {
          // Airtable: after a 429 you must wait 30 seconds.
          if (attempt >= this.maxRetries) throw new ApiError(429, 'Rate limited by Airtable (429). If you are on the Free plan you may have used your 1,000 monthly API calls.', 'RATE_LIMIT');
          this.onWait(30000); await this.wait(30000); continue;
        }
        if (res.status >= 500 && attempt < this.maxRetries) { await this.wait(1000 * 2 ** attempt); continue; }
        let body = null;
        try { body = await res.json(); } catch (_) { /* ignore */ }
        if (!res.ok) {
          const err = body && body.error;
          const type = (err && (err.type || err)) || 'HTTP_' + res.status;
          const msg = (res.status === 401 || res.status === 403 || res.status === 404) ? friendly(res.status) : ((err && err.message) || friendly(res.status));
          throw new ApiError(res.status, msg, type);
        }
        return body;
      }
    }
    async listBases() {
      const out = []; let offset;
      do { const r = await this.request('/meta/bases', { offset }); out.push(...r.bases); offset = r.offset; } while (offset);
      return out;
    }
    async getTables(baseId) { return (await this.request(`/meta/bases/${baseId}/tables`)).tables; }
    async *iterateRecords(baseId, tableId, { view, fields } = {}) {
      let offset;
      do {
        const r = await this.request(`/${baseId}/${encodeURIComponent(tableId)}`, { pageSize: 100, view, offset, 'fields': fields, cellFormat: 'json' });
        yield r.records; offset = r.offset;
      } while (offset);
    }
  }
  function friendly(status) {
    return ({ 401: 'Token rejected. Check that you pasted the full personal access token.',
      403: 'Token lacks access. Give it the data.records:read and schema.bases:read scopes and add this base.',
      404: 'Base or table not found (or the token was not granted access to it).' })[status] || 'Airtable error ' + status;
  }

  /* ---------- Naming ---------- */
  const RESERVED = /^(con|prn|aux|nul|com[0-9]|lpt[0-9])$/i;
  function sanitize(name, fallback = 'untitled') {
    let s = String(name ?? '').normalize('NFC').replace(/[\u0000-\u001f\u007f<>:"/\\|?*]+/g, '_').replace(/\s+/g, ' ').trim().replace(/[. ]+$/, '');
    if (!s || /^_+$/.test(s)) s = fallback;
    if (RESERVED.test(s.split('.')[0])) s = '_' + s;
    // keep within 120 UTF-16 units without cutting a surrogate pair
    if (s.length > 120) { s = s.slice(0, 120); if (/[\ud800-\udbff]$/.test(s)) s = s.slice(0, -1); }
    return s;
  }
  function splitExt(filename) {
    const m = /^(.*?)(\.[A-Za-z0-9]{1,8})?$/.exec(filename || '');
    return { stem: m[1] || '', ext: m[2] || '' };
  }
  function cellText(v) {
    if (v === null || v === undefined) return '';
    if (Array.isArray(v)) return v.map(cellText).filter(Boolean).join(', ');
    if (typeof v === 'object') return ('value' in v && 'state' in v) ? cellText(v.value) : v.name ?? v.email ?? v.filename ?? v.text ?? v.label ?? JSON.stringify(v);
    return String(v);
  }
  /* template tokens: {field:Name} {filename} {ext} {n} {index} {recordId} {table} */
  function renderTemplate(tpl, ctx) {
    return tpl.replace(/\{(field:([^}]+)|filename|ext|n|index|recordId|table)\}/g, (all, key, fname) => {
      if (fname !== undefined) return cellText(ctx.fields[fname]);
      return ({ filename: ctx.stem, ext: ctx.ext.replace(/^\./, ''), n: String(ctx.n), index: String(ctx.index).padStart(4, '0'), recordId: ctx.recordId, table: ctx.table })[key];
    });
  }
  class Deduper {
    constructor() { this.seen = new Set(); }
    take(path) {
      const key = (p) => p.toLowerCase();
      if (!this.seen.has(key(path))) { this.seen.add(key(path)); return path; }
      const slash = path.lastIndexOf('/');
      const dir = path.slice(0, slash + 1); const { stem, ext } = splitExt(path.slice(slash + 1));
      for (let i = 2; ; i++) { const p = `${dir}${stem} (${i})${ext}`; if (!this.seen.has(key(p))) { this.seen.add(key(p)); return p; } }
    }
  }

  /* ---------- Planning: records -> list of files to download ---------- */
  function planFiles(records, opts) {
    const { tableName, fieldNames, nameTemplate = '{filename}', folderTemplate = '', folderPerRecord = false, prefix = '', dedupe = new Deduper(), startIndex = 0 } = opts;
    const out = []; let index = startIndex;
    for (const rec of records) {
      index++;
      const fields = rec.fields || {};
      let dir = prefix;
      if (folderPerRecord) {
        const folder = folderTemplate ? renderTemplate(folderTemplate, { fields, recordId: rec.id, table: tableName, stem: '', ext: '', n: 1, index }) : (cellText(fields[opts.primaryField]) || rec.id);
        dir += folder.split('/').map((seg) => sanitize(seg, '_')).filter((seg) => seg !== '_').join('/').replace(/^$/, rec.id) + '/';
      }
      let n = 0;
      for (const f of fieldNames) {
        const atts = Array.isArray(fields[f]) ? fields[f] : [];
        for (const a of atts) {
          if (!a || !a.url) continue;
          n++;
          const { stem, ext } = splitExt(a.filename || 'file');
          const rendered = renderTemplate(nameTemplate, { fields, recordId: rec.id, table: tableName, stem, ext, n, index });
          let base = sanitize(rendered, stem || rec.id);
          if (ext && !base.toLowerCase().endsWith(ext.toLowerCase())) base += ext;
          const path = dedupe.take(dir + base);
          out.push({ path, url: a.url, size: a.size || 0, type: a.type || '', recordId: rec.id, field: f, originalName: a.filename || '', table: tableName, attachmentId: a.id || '' });
        }
      }
    }
    return { files: out, lastIndex: index };
  }
  function attachmentFields(table) {
    return table.fields.filter((f) => f.type === 'multipleAttachments').map((f) => f.name);
  }
  function estimateCalls(recordCount) { return 1 + Math.max(1, Math.ceil(recordCount / 100)); }

  /* ---------- CSV ---------- */
  function csvCell(v) {
    let s = String(v ?? '');
    if (/^[=+\-@\t\r]/.test(s)) s = "'" + s; // spreadsheet formula-injection guard
    return /[",\n\r]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
  }
  function buildIndexCsv(rows) {
    const head = ['table', 'record_id', 'field', 'original_filename', 'saved_as', 'size_bytes', 'mime_type', 'status'];
    const lines = [head.join(',')];
    for (const r of rows) lines.push([r.table, r.recordId, r.field, r.originalName, r.path, r.size, r.type, r.status || 'ok'].map(csvCell).join(','));
    return '\ufeff' + lines.join('\r\n') + '\r\n';
  }

  /* ---------- ZIP writer (STORE, no compression: attachments are already compressed) ---------- */
  const CRC_TABLE = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
  function crc32(bytes, crc = 0) {
    crc = ~crc >>> 0;
    for (let i = 0; i < bytes.length; i++) crc = CRC_TABLE[(crc ^ bytes[i]) & 0xff] ^ (crc >>> 8);
    return ~crc >>> 0;
  }
  function dosTime(d) {
    return { time: (d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() >> 1), date: ((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate() };
  }
  /** Collects entries as Uint8Array chunks; produce() returns array of parts (Uint8Array chunks) */
  class ZipWriter {
    constructor(now = new Date()) { this.chunks = []; this.central = []; this.offset = 0; this.count = 0; this.dt = dosTime(now); }
    get size() { return this.offset; }
    add(path, data) {
      const name = new TextEncoder().encode(path);
      const crc = crc32(data); const len = data.length;
      if (len > 0xfffffffe || this.offset + len > 0xfffffffe) throw new Error('ZIP part too large');
      const h = new DataView(new ArrayBuffer(30));
      h.setUint32(0, 0x04034b50, true); h.setUint16(4, 20, true); h.setUint16(6, 0x0800, true); h.setUint16(8, 0, true);
      h.setUint16(10, this.dt.time, true); h.setUint16(12, this.dt.date, true); h.setUint32(14, crc, true);
      h.setUint32(18, len, true); h.setUint32(22, len, true); h.setUint16(26, name.length, true); h.setUint16(28, 0, true);
      const c = new DataView(new ArrayBuffer(46));
      c.setUint32(0, 0x02014b50, true); c.setUint16(4, 20, true); c.setUint16(6, 20, true); c.setUint16(8, 0x0800, true);
      c.setUint16(10, 0, true); c.setUint16(12, this.dt.time, true); c.setUint16(14, this.dt.date, true); c.setUint32(16, crc, true);
      c.setUint32(20, len, true); c.setUint32(24, len, true); c.setUint16(28, name.length, true);
      c.setUint32(42, this.offset, true);
      this.central.push(new Uint8Array(c.buffer), name);
      this.chunks.push(new Uint8Array(h.buffer), name, data);
      this.offset += 30 + name.length + len; this.count++;
    }
    finish() {
      if (this.count > 0xffff) throw new Error('Too many files in one ZIP part');
      const cdSize = this.central.reduce((s, b) => s + b.length, 0);
      const e = new DataView(new ArrayBuffer(22));
      e.setUint32(0, 0x06054b50, true); e.setUint16(8, this.count, true); e.setUint16(10, this.count, true);
      e.setUint32(12, cdSize, true); e.setUint32(16, this.offset, true);
      return [...this.chunks, ...this.central, new Uint8Array(e.buffer)];
    }
  }

  /* ---------- Export runner: downloads files with concurrency, splits into parts ---------- */
  async function runExport({ files, fetchFile, emitPart, onProgress = () => {}, partMaxBytes = 1024 * 1024 * 1024, concurrency = 4, indexName = 'index.csv', signal, extraIndexRows = [], extraFiles = [] }) {
    let zip = new ZipWriter(); let part = 1; const rows = [...extraIndexRows];
    let done = 0, bytes = 0, failed = 0;
    const queue = files.slice(); const results = new Array(files.length);
    let next = 0; let flushChain = Promise.resolve();
    const flush = async (last) => {
      if (zip.count === 0 && !last) return;
      if (last) for (const x of (typeof extraFiles === 'function' ? extraFiles(rows) : extraFiles)) zip.add(x.path, typeof x.data === 'string' ? new TextEncoder().encode(x.data) : x.data);
      if (last) zip.add(indexName, new TextEncoder().encode(buildIndexCsv(rows)));
      const chunks = zip.finish();
      await emitPart(chunks, part, last);
      part++; zip = new ZipWriter();
    };
    async function worker() {
      while (next < queue.length) {
        if (signal && signal.aborted) throw new Error('Cancelled');
        const i = next++; const f = queue[i];
        let data = null, status = 'ok';
        for (let a = 0; a < 3 && !data; a++) {
          try { data = await fetchFile(f); } catch (e) { status = 'failed: ' + e.message; await sleep(500 * (a + 1)); }
        }
        if (data) status = 'ok';
        results[i] = { data, status };
        // write in original order is not required; write as they arrive but serialize writes
        flushChain = flushChain.then(async () => {
          if (data) {
            if (zip.count > 0 && zip.size + data.length + 200 > partMaxBytes) await flush(false);
            zip.add(f.path, data); bytes += data.length;
          } else failed++;
          rows.push({ ...f, status });
          done++; onProgress({ done, total: files.length, bytes, failed, part, current: f.path });
        });
        await flushChain;
      }
    }
    await Promise.all(Array.from({ length: Math.min(concurrency, queue.length || 1) }, worker));
    await flushChain;
    await flush(true);
    return { done, failed, bytes, parts: part - 1, rows };
  }

  /* ---------- License ---------- */
  const LICENSE_TTL_MS = 7 * 24 * 3600 * 1000;
  async function verifyLicense({ endpoint, key, deviceId, fetchImpl = fetch }) {
    const res = await fetchImpl(endpoint, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ license_key: key.trim(), device_id: deviceId }) });
    let body = {}; try { body = await res.json(); } catch (_) {}
    return { valid: !!body.valid, reason: body.reason || (res.ok ? '' : 'server_error'), email: body.email || '' };
  }
  function licenseActive(state, now = Date.now()) {
    return !!(state && state.valid && state.checkedAt && now - state.checkedAt < LICENSE_TTL_MS * 2); // grace: 14 days offline
  }
  function applyFreeLimit(files, pro) {
    if (pro) return { files, truncated: 0 };
    return { files: files.slice(0, FREE_FILE_LIMIT), truncated: Math.max(0, files.length - FREE_FILE_LIMIT) };
  }


  /* ---------- Full backup (v1.1) ---------- */
  function backupText(v, sep = '; ') {
    if (v == null) return '';
    if (Array.isArray(v)) return v.map((x) => backupText(x, sep)).join(sep);
    if (typeof v === 'object') {
      if ('value' in v && 'state' in v) return backupText(v.value, sep); // aiText
      if (v.name || v.email) return v.name || v.email; // collaborator
      if (v.label != null) return String(v.label); // button
      if (v.specialValue) return String(v.specialValue);
      if (v.error) return '#ERROR';
      return JSON.stringify(v);
    }
    return String(v);
  }
  // Plan files for one table page; attachments already in `known` (attId -> path) are skipped but still referenced.
  function planBackup(records, { tableName, table, dedupe = new Deduper(), known = {}, exportedPaths = {} }) {
    const attFields = attachmentFields(table); const files = []; let skipped = 0;
    const dir = sanitize(tableName, 'table') + '/';
    for (const rec of records) {
      for (const f of attFields) {
        for (const a of (Array.isArray(rec.fields[f]) ? rec.fields[f] : [])) {
          if (!a || !a.url) continue;
          if (a.id && known[a.id]) { exportedPaths[a.id] = known[a.id].path; dedupe.take(known[a.id].path); skipped++; continue; }
          const { stem, ext } = splitExt(a.filename || 'file');
          let base = sanitize(a.filename || 'file', stem || 'file'); if (ext && !base.toLowerCase().endsWith(ext.toLowerCase())) base += ext;
          const path = dedupe.take(`${dir}files/${rec.id}/${base}`);
          if (a.id) exportedPaths[a.id] = path;
          files.push({ path, url: a.url, size: a.size || 0, type: a.type || '', recordId: rec.id, field: f, originalName: a.filename || '', table: tableName, attachmentId: a.id || '' });
        }
      }
    }
    return { files, skipped };
  }
  function relTo(fromDir, path) { return path.startsWith(fromDir) ? path.slice(fromDir.length) : '../' + path; }
  function tableFieldOrder(table) {
    const prim = table.fields.find((f) => f.id === table.primaryFieldId) || table.fields[0];
    return [prim, ...table.fields.filter((f) => f !== prim)];
  }
  // records.csv: record_id, created_time, then every field; attachment cells = paths relative to the CSV.
  function buildRecordsCsv(table, records, paths, { notion = false } = {}) {
    const dir = sanitize(table.name, 'table') + '/'; const fields = tableFieldOrder(table);
    const cell = (rec, f) => {
      const v = rec.fields[f.name];
      if (f.type === 'multipleAttachments') return (Array.isArray(v) ? v : []).map((a) => (paths[a.id] ? relTo(dir, paths[a.id]) : a.filename || '')).join(notion ? ', ' : '; ');
      if (f.type === 'checkbox') return v ? (notion ? 'Yes' : 'true') : (notion ? 'No' : 'false');
      return backupText(v, notion ? ', ' : '; ');
    };
    if (notion) { // Notion: first column becomes the page title; no formula guard (Notion shows text literally)
      const esc = (s) => (/[",\n\r]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s);
      const head = [...fields.map((f) => f.name), 'Airtable record ID'];
      return '\ufeff' + [head.map(esc).join(','), ...records.map((r) => [...fields.map((f) => cell(r, f)), r.id].map((x) => esc(String(x))).join(','))].join('\r\n') + '\r\n';
    }
    const head = ['record_id', 'created_time', ...fields.map((f) => f.name)];
    return '\ufeff' + [head.map(csvCell).join(','), ...records.map((r) => [r.id, r.createdTime || '', ...fields.map((f) => cell(r, f))].map(csvCell).join(','))].join('\r\n') + '\r\n';
  }
  // records.json: raw API records, attachment url/thumbnails (expiring) replaced by local relative path.
  function buildRecordsJson(table, records, paths) {
    const dir = sanitize(table.name, 'table') + '/'; const att = new Set(attachmentFields(table));
    return JSON.stringify({ table: { id: table.id, name: table.name }, records: records.map((r) => ({ id: r.id, createdTime: r.createdTime, fields: Object.fromEntries(Object.entries(r.fields).map(([k, v]) => [k, att.has(k) && Array.isArray(v) ? v.map(({ url, thumbnails, ...a }) => ({ ...a, localPath: paths[a.id] ? relTo(dir, paths[a.id]) : null })) : v])) })) }, null, 2);
  }
  function buildManifest({ baseId, baseName, prev, exported, exportedAt, calls, failedIds = [] }) {
    const attachments = { ...((prev && prev.attachments) || {}) };
    const bad = new Set(failedIds);
    for (const f of exported) if (f.attachmentId && !bad.has(f.attachmentId)) attachments[f.attachmentId] = { path: f.path, size: f.size, table: f.table, recordId: f.recordId };
    return { format: 'basedrop-backup/1', baseId, baseName, exportedAt, runs: [...((prev && prev.runs) || []), { at: exportedAt, newFiles: exported.length - bad.size, apiCalls: calls }].slice(-50), attachments };
  }
  function estimateBackupCalls(tableCount, prev) {
    const last = prev && prev.runs && prev.runs.length ? prev.runs[prev.runs.length - 1].apiCalls : null;
    return { minimum: tableCount, last };
  }

  return { backupText, planBackup, buildRecordsCsv, buildRecordsJson, buildManifest, estimateBackupCalls, relTo, API, FREE_FILE_LIMIT, RateLimiter, AirtableClient, ApiError, sanitize, splitExt, cellText, renderTemplate, Deduper, planFiles, attachmentFields, estimateCalls, csvCell, buildIndexCsv, crc32, ZipWriter, runExport, verifyLicense, licenseActive, applyFreeLimit, LICENSE_TTL_MS };
});
