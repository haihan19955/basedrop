// Filled in at release time. LICENSE_ENDPOINT = deployed Cloudflare Worker URL.
self.BASEDROP_CONFIG = {
  LICENSE_ENDPOINT: 'https://basedrop-license.steadyflowsheets.workers.dev/verify',
  BUY_URL: 'https://payhip.com/b/qokFH',
  SITE_URL: 'https://haihan19955.github.io/basedrop/',
  PART_MAX_BYTES: 500 * 1024 * 1024
};
