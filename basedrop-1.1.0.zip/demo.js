/* Demo / screenshot mode: only active when the page URL contains ?demo=… . Never used in normal runs. */
(() => {
  const q = new URLSearchParams(location.search); const scene = q.get('demo');
  if (!scene) { self.BaseDropDemo = { active: false }; return; }
  const names = ['Aurora Studio', 'Bluebird Café', 'Cedar & Co', 'Delta Logistics', 'Evergreen Dental', 'Foxglove Florist', 'Granite Fitness', 'Harbor Realty'];
  const recs = Array.from({ length: 240 }, (_, i) => ({ id: 'rec' + String(100000 + i).padStart(14, 'A'), fields: { Name: names[i % 8] + (i >= 8 ? ' #' + (Math.floor(i / 8) + 1) : ''), Status: ['Approved', 'In review', 'Draft'][i % 3], Client: names[(i + 3) % 8], Logo: [{ id: 'att' + i, url: 'https://v5.airtableusercontent.com/demo/' + i, filename: 'logo.png', size: 38213 + i * 97, type: 'image/png' }], Photos: Array.from({ length: (i % 3) + 1 }, (_, k) => ({ id: 'att' + i + 'p' + k, url: 'https://v5.airtableusercontent.com/demo/p' + i + k, filename: 'IMG_' + (2000 + i * 3 + k) + '.jpg', size: 118432 + k * 5123, type: 'image/jpeg' })) } }));
  const tables = [{ id: 'tblProjects', name: 'Projects', primaryFieldId: 'fldName', fields: [{ id: 'fldName', name: 'Name', type: 'singleLineText' }, { id: 'f2', name: 'Status', type: 'singleSelect' }, { id: 'f3', name: 'Client', type: 'singleLineText' }, { id: 'f4', name: 'Logo', type: 'multipleAttachments' }, { id: 'f5', name: 'Photos', type: 'multipleAttachments' }], views: [{ id: 'viwAll', name: 'Grid view', type: 'grid' }, { id: 'viwApproved', name: 'Approved only', type: 'grid' }] },
    { id: 'tblInvoices', name: 'Invoices', primaryFieldId: 'g1', fields: [{ id: 'g1', name: 'Invoice #', type: 'singleLineText' }, { id: 'g2', name: 'PDF', type: 'multipleAttachments' }], views: [{ id: 'viwI', name: 'Grid view', type: 'grid' }] }];
  const json = (b) => new Response(JSON.stringify(b), { status: 200, headers: { 'Content-Type': 'application/json' } });
  const slow = scene === 'progress';
  async function demoFetch(url, init) {
    const u = new URL(url);
    if (u.pathname === '/v0/meta/bases') return json({ bases: [{ id: 'appDemo1', name: 'Client Projects 2026' }, { id: 'appDemo2', name: 'Marketing Assets' }] });
    if (u.pathname.endsWith('/tables')) return json({ tables });
    if (u.hostname === 'api.airtable.com') { const off = +(u.searchParams.get('offset') || 0); return json({ records: recs.slice(off, off + 100), offset: off + 100 < recs.length ? String(off + 100) : undefined }); }
    if (url.includes('workers.dev') || url.includes('REPLACE_ME')) return json({ valid: true, email: 'demo@example.com' });
    if (slow) await new Promise((r) => setTimeout(r, 900));
    const m = /\/(p?)(\d+)$/.exec(u.pathname); const r = recs[+String(m[2]).slice(0, m[1] ? -1 : undefined)] ; const a = m[1] ? r.fields.Photos[+m[2].slice(-1)] : r.fields.Logo[0]; return new Response(new Uint8Array(a.size));
  }
  self.BaseDropDemo = {
    active: true, fetch: demoFetch, sampleRecord: recs[0],
    async setup({ $, store }) {
      await store.set('token', 'patDEMO.' + 'x'.repeat(40));
      if (scene !== 'free') await store.set('license', { key: 'DEMO', valid: true, checkedAt: Date.now() });
      else await store.set('license', null);
      if (scene === 'connect') { await store.set('token', null); return; }
      setTimeout(() => {
        if (scene === 'pro' || scene === 'progress' || scene === 'done') { $('nameTpl').value = '{field:Client} - {field:Name} - {n}'; $('folderPer').checked = true; $('folderTpl').value = '{field:Status}/{field:Name}'; $('nameTpl').dispatchEvent(new Event('input')); }
        if (scene === 'progress' || scene === 'done') $('startBtn').click();
      }, 400);
    }
  };
})();
