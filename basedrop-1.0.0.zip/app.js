/* global BaseDrop, BASEDROP_CONFIG, BaseDropDemo, chrome */
(() => {
  'use strict';
  const B = BaseDrop, CFG = self.BASEDROP_CONFIG;
  const $ = (id) => document.getElementById(id);
  const hasChrome = typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local;
  const store = {
    async get(k) { if (hasChrome) return (await chrome.storage.local.get(k))[k]; try { return JSON.parse(localStorage.getItem(k)); } catch (_) { return null; } },
    async set(k, v) { if (hasChrome) return chrome.storage.local.set({ [k]: v }); localStorage.setItem(k, JSON.stringify(v)); }
  };
  const demo = self.BaseDropDemo && BaseDropDemo.active ? BaseDropDemo : null;
  const fetchImpl = demo ? demo.fetch : (...a) => fetch(...a);
  let client, tables = [], pro = false, abort = null;

  const setStatus = (el, msg, kind = '') => { el.textContent = msg; el.className = 'status ' + kind; };
  const fmtBytes = (n) => n < 1024 ? n + ' B' : n < 1048576 ? (n / 1024).toFixed(1) + ' KB' : n < 1073741824 ? (n / 1048576).toFixed(1) + ' MB' : (n / 1073741824).toFixed(2) + ' GB';
  const opt = (v, t) => { const o = document.createElement('option'); o.value = v; o.textContent = t; return o; };

  async function deviceId() {
    let id = await store.get('deviceId');
    if (!id) { id = crypto.randomUUID(); await store.set('deviceId', id); }
    return id;
  }
  function renderPlan() {
    $('planBadge').textContent = pro ? 'Pro · unlimited' : 'Free · ' + B.FREE_FILE_LIMIT + ' files / run';
    $('planBadge').classList.toggle('is-pro', pro);
    document.querySelectorAll('.pro').forEach((e) => { e.hidden = pro; });
    $('licenseCard').hidden = pro;
    renderPreview();
  }

  /* ---------- connect ---------- */
  async function connect() {
    const token = $('token').value.trim();
    if (!token) return setStatus($('connectStatus'), 'Paste your personal access token first.', 'bad');
    $('connectBtn').disabled = true; setStatus($('connectStatus'), 'Connecting…');
    try {
      client = new B.AirtableClient(token, { fetch: fetchImpl, onWait: () => setStatus($('runStatus'), 'Airtable asked us to slow down – waiting 30 s…') });
      const bases = await client.listBases();
      if (!bases.length) throw new Error('This token has no bases. Edit the token and add the bases you want to download from.');
      await store.set('token', token);
      $('base').replaceChildren(...bases.map((b) => opt(b.id, b.name)));
      setStatus($('connectStatus'), `Connected · ${bases.length} base${bases.length > 1 ? 's' : ''} available`, 'ok');
      $('pickCard').hidden = false; $('howCard').hidden = true; await loadBase();
    } catch (e) { setStatus($('connectStatus'), e.message, 'bad'); }
    finally { $('connectBtn').disabled = false; }
  }
  async function loadBase() {
    tables = await client.getTables($('base').value);
    const withAtt = tables.filter((t) => B.attachmentFields(t).length);
    $('table').replaceChildren(...(withAtt.length ? withAtt : tables).map((t) => opt(t.id, t.name + (B.attachmentFields(t).length ? '' : ' (no attachment fields)'))));
    loadTable();
  }
  function curTable() { return tables.find((t) => t.id === $('table').value); }
  function loadTable() {
    const t = curTable(); const whole = $('scope').value === 'base';
    $('tableWrap').hidden = whole; $('viewWrap').hidden = whole;
    if (!t) return;
    $('view').replaceChildren(opt('', 'All records'), ...(t.views || []).filter((v) => v.type === 'grid' || !v.type || true).map((v) => opt(v.id, v.name)));
    const fieldNames = whole ? [...new Set(tables.flatMap(B.attachmentFields))] : B.attachmentFields(t);
    $('fields').replaceChildren(...fieldNames.map((f) => { const l = document.createElement('label'); l.className = 'chip'; l.innerHTML = '<input type="checkbox" checked>'; l.querySelector('input').value = f; l.append(f); return l; }));
    $('fieldsWrap').hidden = !fieldNames.length;
    const primary = t.fields.find((f) => f.id === t.primaryFieldId) || t.fields[0];
    $('tokens').replaceChildren(...['{filename}', '{n}', '{index}', '{recordId}', '{table}', ...t.fields.filter((f) => f.type !== 'multipleAttachments').slice(0, 12).map((f) => `{field:${f.name}}`)].map((s) => { const b = document.createElement('span'); b.className = 'tok'; b.textContent = s; b.title = 'Click to insert into file name'; b.onclick = () => { if (!pro) return; $('nameTpl').value += (s === '{filename}' ? '' : ' ') + s; renderPreview(); }; return b; }));
    if (!$('folderTpl').dataset.touched && primary) $('folderTpl').value = `{field:${primary.name}}`;
    $('nameCard').hidden = false; $('runCard').hidden = false;
    $('estimate').textContent = whole ? `Whole base: ${tables.filter((x) => B.attachmentFields(x).length).length} table(s) with attachments. Each 100 records = 1 Airtable API call (Free plan: 1,000 calls / month). Downloading the files themselves does not use API calls.` : 'Each 100 records = 1 Airtable API call (Free plan: 1,000 calls / month). Downloading the files themselves does not use API calls.';
    renderPreview();
  }
  function selectedFields() { return [...$('fields').querySelectorAll('input:checked')].map((i) => i.value); }
  function namingOpts() {
    return pro ? { nameTemplate: $('nameTpl').value || '{filename}', folderPerRecord: $('folderPer').checked, folderTemplate: $('folderTpl').value } : { nameTemplate: '{filename}', folderPerRecord: false };
  }
  function renderPreview() {
    const t = curTable(); if (!t) return;
    $('folderTplWrap').hidden = !$('folderPer').checked;
    const sample = demo ? demo.sampleRecord : { id: 'recXXXXXXXXXXXXXX', fields: Object.fromEntries(t.fields.map((f) => [f.name, f.type === 'multipleAttachments' ? [{ url: 'x', filename: 'original-name.jpg' }] : '[' + f.name + ']'])) };
    const plan = B.planFiles([sample], { tableName: t.name, fieldNames: selectedFields().slice(0, 1), primaryField: (t.fields.find((f) => f.id === t.primaryFieldId) || t.fields[0]).name, ...namingOpts() });
    $('preview').textContent = 'Preview →  ' + (plan.files.map((f) => f.path).slice(0, 3).join('\n             ') || '(no attachments in sample)') + (pro ? '' : '\n(Free plan keeps original file names – activate Pro to use templates)');
    $('nameTpl').disabled = !pro; $('folderPer').disabled = !pro; $('folderTpl').disabled = !pro;
    $('scope').querySelector('option[value=base]').textContent = 'Whole base (every table with attachments)' + (pro ? '' : ' – Pro');
  }

  /* ---------- run ---------- */
  async function saveBlob(blob, filename) {
    const url = URL.createObjectURL(blob);
    try {
      if (hasChrome && chrome.downloads) await chrome.downloads.download({ url, filename, conflictAction: 'uniquify' });
      else { const a = document.createElement('a'); a.href = url; a.download = filename.split('/').pop(); document.body.append(a); a.click(); a.remove(); }
    } finally { setTimeout(() => URL.revokeObjectURL(url), 120000); }
  }
  async function start() {
    const fieldNames = selectedFields();
    if (!fieldNames.length) return setStatus($('runStatus'), 'Pick at least one attachment field.', 'bad');
    const whole = $('scope').value === 'base';
    if (whole && !pro) return setStatus($('runStatus'), 'Whole-base export is a Pro feature. Pick one table, or activate Pro below.', 'bad');
    abort = new AbortController(); $('startBtn').disabled = true; $('cancelBtn').hidden = false; $('progressWrap').hidden = false;
    const baseName = $('base').selectedOptions[0].textContent;
    const d0 = new Date(); const p2 = (x) => String(x).padStart(2, '0'); const stamp = `${d0.getFullYear()}-${p2(d0.getMonth() + 1)}-${p2(d0.getDate())} ${p2(d0.getHours())}${p2(d0.getMinutes())}`;
    try {
      const targets = whole ? tables.filter((t) => B.attachmentFields(t).some((f) => fieldNames.includes(f))) : [curTable()];
      const dedupe = new B.Deduper(); let files = []; const callsBefore = client.calls;
      for (const t of targets) {
        const fn = B.attachmentFields(t).filter((f) => fieldNames.includes(f));
        const primary = (t.fields.find((f) => f.id === t.primaryFieldId) || t.fields[0]).name;
        const fetchFields = [...new Set([...fn, primary, ...[...($('nameTpl').value + $('folderTpl').value).matchAll(/\{field:([^}]+)\}/g)].map((m) => m[1])])].filter((f) => t.fields.some((x) => x.name === f));
        let idx = 0;
        for await (const page of client.iterateRecords($('base').value, t.id, { view: whole ? undefined : $('view').value, fields: fetchFields })) {
          if (abort.signal.aborted) throw new Error('Cancelled');
          const p = B.planFiles(page, { tableName: t.name, fieldNames: fn, primaryField: primary, prefix: whole && !(pro && $('folderPer').checked && $('folderTpl').value.includes('{table}')) ? B.sanitize(t.name) + '/' : '', dedupe, startIndex: idx, ...namingOpts() });
          idx = p.lastIndex; files.push(...p.files);
          $('progressText').textContent = `Scanning ${t.name}: ${idx} records, ${files.length} attachments found…`;
        }
      }
      const { files: run, truncated } = B.applyFreeLimit(files, pro);
      if (!run.length) throw new Error('No attachments found in this selection.');
      const totalBytes = run.reduce((s, f) => s + (f.size || 0), 0);
      const zipBase = B.sanitize(`${baseName}${whole ? '' : ' - ' + curTable().name} ${stamp}`);
      const res = await B.runExport({
        files: run, signal: abort.signal, partMaxBytes: CFG.PART_MAX_BYTES,
        fetchFile: async (f) => { const r = await fetchImpl(f.url, { signal: abort.signal }); if (!r.ok) throw new Error('HTTP ' + r.status); return new Uint8Array(await r.arrayBuffer()); },
        emitPart: async (chunks, part, last) => saveBlob(new Blob(chunks, { type: 'application/zip' }), `BaseDrop/${zipBase}${part > 1 || !last ? ' part ' + part : ''}.zip`),
        onProgress: (p) => { $('bar').style.width = (100 * p.done / p.total).toFixed(1) + '%'; $('progressText').textContent = `${p.done} / ${p.total} files · ${fmtBytes(p.bytes)}${totalBytes ? ' of ~' + fmtBytes(totalBytes) : ''}${p.failed ? ' · ' + p.failed + ' failed' : ''}\n${p.current}`; }
      });
      $('bar').style.width = '100%';
      const msg = `Done: ${res.done - res.failed} files (${fmtBytes(res.bytes)}) in ${res.parts} ZIP${res.parts > 1 ? 's' : ''}, ${client.calls - callsBefore} API calls used.` + (res.failed ? ` ${res.failed} failed – see index.csv.` : '') + (truncated ? ` Free plan: ${truncated} more attachment(s) were skipped. Activate Pro to get them all.` : '');
      setStatus($('runStatus'), msg, res.failed ? 'bad' : 'ok');
    } catch (e) { setStatus($('runStatus'), e.message, 'bad'); }
    finally { $('startBtn').disabled = false; $('cancelBtn').hidden = true; }
  }

  /* ---------- license ---------- */
  async function activate() {
    const key = $('licKey').value.trim(); if (!key) return setStatus($('licStatus'), 'Paste your license key.', 'bad');
    $('licBtn').disabled = true; setStatus($('licStatus'), 'Checking…');
    try {
      const r = await B.verifyLicense({ endpoint: CFG.LICENSE_ENDPOINT, key, deviceId: await deviceId(), fetchImpl: demo ? demo.fetch : fetch });
      if (!r.valid) { setStatus($('licStatus'), ({ device_limit: 'This key is already active on 3 devices. Email support to move it.', disabled: 'This key was disabled (refunded or revoked).', not_found: 'Key not found. Copy it exactly from your Payhip receipt.' })[r.reason] || 'Could not verify the key right now. Try again in a minute.', 'bad'); return; }
      await store.set('license', { key, valid: true, checkedAt: Date.now(), email: r.email }); pro = true; renderPlan();
      setStatus($('licStatus'), 'Pro activated. Thank you!', 'ok');
    } catch (e) { setStatus($('licStatus'), 'Network error: ' + e.message, 'bad'); }
    finally { $('licBtn').disabled = false; }
  }
  async function refreshLicense() {
    const lic = await store.get('license'); pro = B.licenseActive(lic);
    if (lic && lic.valid && Date.now() - lic.checkedAt > B.LICENSE_TTL_MS && !demo) {
      try { const r = await B.verifyLicense({ endpoint: CFG.LICENSE_ENDPOINT, key: lic.key, deviceId: await deviceId() }); if (r.valid || r.reason === 'server_error') { if (r.valid) await store.set('license', { ...lic, checkedAt: Date.now() }); } else { await store.set('license', null); pro = false; } } catch (_) { /* offline grace */ }
    }
    renderPlan();
  }

  /* ---------- wire ---------- */
  $('buyLink').href = CFG.BUY_URL;
  $('connectBtn').onclick = connect; $('token').onkeydown = (e) => { if (e.key === 'Enter') connect(); };
  $('base').onchange = loadBase; $('table').onchange = loadTable; $('scope').onchange = loadTable;
  $('fields').onchange = renderPreview; ['nameTpl', 'folderTpl'].forEach((id) => { $(id).oninput = () => { $(id).dataset.touched = 1; renderPreview(); }; });
  $('folderPer').onchange = renderPreview; $('startBtn').onclick = start; $('cancelBtn').onclick = () => abort && abort.abort();
  $('licBtn').onclick = activate;
  (async () => {
    if (demo) await demo.setup({ $, store });
    await refreshLicense();
    const t = await store.get('token'); if (t) { $('token').value = t; connect(); }
  })();
})();
